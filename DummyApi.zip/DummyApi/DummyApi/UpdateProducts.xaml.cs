﻿using Dominio.Entity;
using Newtonsoft.Json;
using Service.Path;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DummyApi
{
    /// <summary>
    /// Lógica interna para UpdateProducts.xaml
    /// </summary>
    public partial class UpdateProducts : Window
    {
        public UpdateProducts()
        {
            InitializeComponent();
        }

        private async void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product newProduct = new Product();

                bool isAdded = await ProductService.UpdateProductAsync(long.Parse(txtId.Text), newProduct);

                if (isAdded)
                {
                    MessageBox.Show("Novo produto adicionado com sucesso!");
                }
                else
                {
                    MessageBox.Show("Não foi possível adicionar o novo produto.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
    }
}