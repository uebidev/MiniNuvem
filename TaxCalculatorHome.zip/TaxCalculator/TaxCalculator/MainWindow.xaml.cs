﻿using MaterialDesignThemes.Wpf.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TaxCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Rectangle_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {

        }

        private void BtnMenuShowSideBar_Click(object sender, RoutedEventArgs e)
        {
            if (SideBarMenu.Height == 100)
            {
                while (SideBarMenu.Height != 900)
                {
                    SideBarMenu.Height++;
                }
            }
            else if (SideBarMenu.Height == 900)
            {
                while (SideBarMenu.Height != 100)
                {
                    SideBarMenu.Height--;
                }
            }

        }

        private void BtnShowInput_Click(object sender, RoutedEventArgs e)
        {
            //if(Inputs.Visibility!=Visibility.Visible)
            //Inputs.Visibility = Visibility.Visible;
            //else
            //    Inputs.Visibility = Visibility.Collapsed;
            if (Inputs.Height == 0)
            {
                while (Inputs.Height != 360)
                {
                    Inputs.Height++;
                }
            }
            else if (Inputs.Height == 360)
            {
                while (Inputs.Height != 0)
                {
                    Inputs.Height--;
                }
            }


        }

        private void BtnShowCalculator_Click(object sender, RoutedEventArgs e)
        {
            if (calculatorApp.Visibility != Visibility.Visible)
                calculatorApp.Visibility = Visibility.Visible;
            else
                calculatorApp.Visibility = Visibility.Collapsed;
        }

        private void BtnShowCalculator_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void BtnMin_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            // Verifica se a tecla pressionada é a vírgula (",") ou o ponto (".").
            if (e.Key == Key.OemComma || e.Key == Key.Decimal)
            {
                // Verifica se já há uma vírgula (",") ou um ponto (".") no texto.
                if (textBox.Text.Contains(",") || textBox.Text.Contains("."))
                {
                    // Impede a inserção adicional da vírgula (",") ou do ponto (".").
                    e.Handled = true;
                }
                else
                {
                    // Insere a vírgula (",") ou o ponto (".") no TextBox.
                    int caretIndex = textBox.CaretIndex;
                    textBox.Text = textBox.Text.Insert(caretIndex, ",");
                    textBox.CaretIndex = caretIndex + 1;

                    // Impede que a tecla seja processada novamente.
                    e.Handled = true;
                }
            }

            // Verifica se a tecla pressionada não é um número (0-9), "." ou "," e não é a tecla Backspace.
            if (!((e.Key >= Key.D0 && e.Key <= Key.D9) ||
              (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) ||
              e.Key == Key.Back || e.Key == Key.Decimal || e.Key == Key.OemComma || e.Key == Key.OemPeriod))
            {
                // Impede que a tecla seja processada.
                e.Handled = true;
            }
            else
            {
                // Verifica se "." ou "," já foi digitado e impede a entrada de um segundo separador.
                var text = textBox.Text;
                if ((e.Key == Key.Decimal || e.Key == Key.OemComma || e.Key == Key.OemPeriod) &&
                    (text.Contains(".") || text.Contains(",")))
                {
                    e.Handled = true;
                }
            }



        }
    }
}
